// ==UserScript==
// @name         Hackers News scroll to next comment like Reddit
// @namespace    https://news.ycombinator.com/
// @version      0.1
// @description  Adds a button and keyboard shortcuts (down and up arrows) that scroll to quickly and smoothly navigate to the next/previous top-level comment like Reddit.
// @author       Tam
// @match        https://news.ycombinator.com/item?id=*
// @grant        none
// @downloadURL
// @updateURL
// @license MIT
// @downloadURL https://update.greasyfork.org/scripts/576827/Hackers%20News%20scroll%20to%20next%20comment%20like%20Reddit.user.js
// @updateURL https://update.greasyfork.org/scripts/576827/Hackers%20News%20scroll%20to%20next%20comment%20like%20Reddit.meta.js
// ==/UserScript==

(function() {
    'use strict';
    const button = document.createElement('button');
    button.textContent = 'v';
    button.style.cssText = `
        position: fixed;
        bottom: 15px;
        right: 15px;
        z-index: 999;
        background-color: #E67C99;
        color: #fff;
        border-radius: 50%;
        width: 40px;
        height: 40px;
        font-size: 20px;
        text-align: center;
        line-height: 40px;
        cursor: pointer;
        display: flex;
        justify-content: center;
        align-items: center;
    `;
    document.body.appendChild(button);

    const comments = [...document.querySelectorAll('td.ind[indent="0"]')];
    let lastCommentIndex = 0;

    button.addEventListener('click', scrollToNextComment);
    document.addEventListener("keydown", handleKeyPress);

    function handleKeyPress(event) {
        if (event.code === "ArrowDown") {
            event.preventDefault();
            scrollToNextComment();
        } else if (event.code === "ArrowUp") {
            event.preventDefault();
            scrollToPreviousComment();
        }
    }

    function getCurrentCommentIndex() {
        const scrollTop = window.scrollY;
        const viewportHeight = window.innerHeight;

        // Find the comment that is currently visible in the viewport
        let currentIndex = -1;
        let maxVisible = 0;

        comments.forEach((comment, index) => {
            const rect = comment.closest('tr').getBoundingClientRect();
            const elemTop = rect.top + scrollTop;
            const elemBottom = elemTop + rect.height;

            // Calculate how much of the comment is visible in the viewport
            const visibleTop = Math.max(elemTop, scrollTop);
            const visibleBottom = Math.min(elemBottom, scrollTop + viewportHeight);
            const visibleHeight = Math.max(0, visibleBottom - visibleTop);

            // Also check if the comment is near the top of the viewport (prioritize top-visible)
            if (rect.top >= -rect.height && rect.top <= viewportHeight / 2) {
                if (currentIndex === -1 || rect.top < comments[currentIndex].closest('tr').getBoundingClientRect().top) {
                    currentIndex = index;
                }
            }
        });

        return currentIndex;
    }

    function scrollToNextComment() {
        const currentIndex = getCurrentCommentIndex();
        let targetIndex;

        if (currentIndex === -1) {
            // No visible comment found, continue from last known position
            if (lastCommentIndex === comments.length - 1) {
                targetIndex = 0;
            } else {
                targetIndex = lastCommentIndex + 1;
            }
        } else {
            // Found visible comment, update last known position
            if (currentIndex === comments.length - 1) {
                // At last comment, wrap to first
                targetIndex = 0;
            } else {
                targetIndex = currentIndex + 1;
            }
        }

        lastCommentIndex = targetIndex;
        comments[targetIndex].closest('tr').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }

    function scrollToPreviousComment() {
        const currentIndex = getCurrentCommentIndex();
        let targetIndex;

        if (currentIndex === -1) {
            // No visible comment found, continue from last known position
            if (lastCommentIndex === 0) {
                targetIndex = comments.length - 1;
            } else {
                targetIndex = lastCommentIndex - 1;
            }
        } else {
            // Found visible comment, update last known position
            if (currentIndex === 0) {
                // At first comment, wrap to last
                targetIndex = comments.length - 1;
            } else {
                targetIndex = currentIndex - 1;
            }
        }

        lastCommentIndex = targetIndex;
        comments[targetIndex].closest('tr').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
})();
